import Main  from "./Main.js";


export default function Home() {
  return (
    <>
      <Main/>  
    </>
  );
}
